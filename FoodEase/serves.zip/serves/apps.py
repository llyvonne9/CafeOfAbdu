from django.apps import AppConfig


class ServesConfig(AppConfig):
    name = 'serves'

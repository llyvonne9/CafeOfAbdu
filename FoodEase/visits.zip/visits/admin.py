from django.contrib import admin

# Register your models here.
from .models import Visits

admin.site.register(Visits)